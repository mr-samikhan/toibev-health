import tasksIcon from "./task_square.svg";
import medicineIcon from "./medicine.svg";
import dashboardIcon from "./dashboard.svg";
import LearnIcon from "./learn.svg";
import eventIcon from "./event.svg";
import adminIcon from "./admin.svg";
import informationIcon from "./information.svg";
import assesmentIcon from "./assesments.svg";
import hamburgerIcon from "./hamburger.svg";

export default {
  tasksIcon,
  medicineIcon,
  dashboardIcon,
  LearnIcon,
  eventIcon,
  adminIcon,
  informationIcon,
  assesmentIcon,
  hamburgerIcon,
};
