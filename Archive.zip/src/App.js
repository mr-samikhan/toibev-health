import { Router } from "./Router/router";

function App() {
  return <Router />;
}

export default App;
